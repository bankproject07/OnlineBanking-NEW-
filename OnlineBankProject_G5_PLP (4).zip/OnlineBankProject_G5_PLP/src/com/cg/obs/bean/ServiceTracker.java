package com.cg.obs.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Service_Tracker")

public class ServiceTracker {

	@Id
	private int service_ID;
	private String service_Description;
	private Long account_ID;
	private Date service_Raised_Date;
	private String service_Status;
	public int getService_ID() {
		return service_ID;
	}
	public void setService_ID(int service_ID) {
		this.service_ID = service_ID;
	}
	public String getService_Description() {
		return service_Description;
	}
	public void setService_Description(String service_Description) {
		this.service_Description = service_Description;
	}
	public Long getAccount_ID() {
		return account_ID;
	}
	public void setAccount_ID(Long account_ID) {
		this.account_ID = account_ID;
	}
	public Date getService_Raised_Date() {
		return service_Raised_Date;
	}
	public void setService_Raised_Date(Date service_Raised_Date) {
		this.service_Raised_Date = service_Raised_Date;
	}
	public String getService_Status() {
		return service_Status;
	}
	public void setService_Status(String service_Status) {
		this.service_Status = service_Status;
	}
	public ServiceTracker(int service_ID, String service_Description, Long account_ID, Date service_Raised_Date,
			String service_Status) {
		super();
		this.service_ID = service_ID;
		this.service_Description = service_Description;
		this.account_ID = account_ID;
		this.service_Raised_Date = service_Raised_Date;
		this.service_Status = service_Status;
	}
	public ServiceTracker() {
		super();
	}
	@Override
	public String toString() {
		return "ServiceTracker [service_ID=" + service_ID + ", service_Description=" + service_Description
				+ ", account_ID=" + account_ID + ", service_Raised_Date=" + service_Raised_Date + ", service_Status="
				+ service_Status + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + service_ID;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceTracker other = (ServiceTracker) obj;
		if (service_ID != other.service_ID)
			return false;
		return true;
	}
	
	
	
	
}
